package com.example.tw

import android.content.Intent
import android.opengl.GLES10
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.bactivity_main.*
import javax.microedition.khronos.opengles.GL10


class BMainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.bactivity_main)

        btn_two.setOnClickListener {
            val intent = Intent(this, CMainActivity::class.java)
            startActivity(intent)


        }
    }
}