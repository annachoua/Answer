package com.example.tw

import android.opengl.GLES10
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.cactivity_main.*
import java.util.*
import javax.microedition.khronos.opengles.GL10


class CMainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cactivity_main)

        val dice_imgs = arrayOf(R.drawable.
        a_1, R.drawable.a_2, R.drawable.a_3, R.drawable.a_4, R.drawable.a_5)
        val r = Random()
        var x = 0
        btn_random.setOnClickListener{
            x = r.nextInt(5)
            iv_dice.setImageResource(dice_imgs[x])


        }
    }
}