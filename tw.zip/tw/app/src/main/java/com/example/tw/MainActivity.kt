package com.example.tw

import android.content.Intent
import android.opengl.GLES10
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import javax.microedition.khronos.opengles.GL10


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_one.setOnClickListener{
            val intent = Intent(this, BMainActivity::class.java)
            startActivity(intent)


        }
    }
}
